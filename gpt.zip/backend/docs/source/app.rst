app package
===========

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   app.api
   app.core
   app.db
   app.models
   app.schemas
   app.services

Submodules
----------

app.main module
---------------

.. automodule:: app.main
   :members:
   :show-inheritance:
   :undoc-members:

app.seed\_users module
----------------------

.. automodule:: app.seed_users
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: app
   :members:
   :show-inheritance:
   :undoc-members:
