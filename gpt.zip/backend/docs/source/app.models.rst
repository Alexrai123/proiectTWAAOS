app.models package
==================

Submodules
----------

app.models.alembic\_tmp\_add\_group\_name\_exam\_user module
------------------------------------------------------------

.. automodule:: app.models.alembic_tmp_add_group_name_exam_user
   :members:
   :show-inheritance:
   :undoc-members:

app.models.discipline module
----------------------------

.. automodule:: app.models.discipline
   :members:
   :show-inheritance:
   :undoc-members:

app.models.exam module
----------------------

.. automodule:: app.models.exam
   :members:
   :show-inheritance:
   :undoc-members:

app.models.room module
----------------------

.. automodule:: app.models.room
   :members:
   :show-inheritance:
   :undoc-members:

app.models.schedule module
--------------------------

.. automodule:: app.models.schedule
   :members:
   :show-inheritance:
   :undoc-members:

app.models.user module
----------------------

.. automodule:: app.models.user
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: app.models
   :members:
   :show-inheritance:
   :undoc-members:
