app.schemas package
===================

Submodules
----------

app.schemas.auth module
-----------------------

.. automodule:: app.schemas.auth
   :members:
   :show-inheritance:
   :undoc-members:

app.schemas.discipline module
-----------------------------

.. automodule:: app.schemas.discipline
   :members:
   :show-inheritance:
   :undoc-members:

app.schemas.exam module
-----------------------

.. automodule:: app.schemas.exam
   :members:
   :show-inheritance:
   :undoc-members:

app.schemas.exam\_display module
--------------------------------

.. automodule:: app.schemas.exam_display
   :members:
   :show-inheritance:
   :undoc-members:

app.schemas.room module
-----------------------

.. automodule:: app.schemas.room
   :members:
   :show-inheritance:
   :undoc-members:

app.schemas.user module
-----------------------

.. automodule:: app.schemas.user
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: app.schemas
   :members:
   :show-inheritance:
   :undoc-members:
